// document.addEventListener("DOMContentLoaded", ()=>{
   
//     let btn_menu = document.getElementById("btn-menu");
//     let menu =  document.getElementById("navbarNavAltMarkup");

  
//     btn_menu.addEventListener("click", e=>{
        
//         console.log(btn_menu.getAttribute("aria-expanded"))
//         if(!btn_menu.getAttribute("aria-expanded")){
//             btn_menu.classList.add("btn_fixed")
//             console.log(btn_menu)
//         }else{
//             btn_menu.classList.remove("btn_fixed")
//             console.log(btn_menu)
//         }


//     })
// });