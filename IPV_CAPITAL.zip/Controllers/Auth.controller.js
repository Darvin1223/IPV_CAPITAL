class Auth {

    login(req,res){
        
    }
    sign_up(req,res){

    }
}

module.exports = new Auth();