module.exports = {
    HomeRoutes: require("./home.routes"),
    AdminRoutes: require('./admin.routes')
}